﻿using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

using CountriesApp.ViewModels;

namespace CountriesApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CountryListView : ContentPage
    {
        CountryListViewModel vm;

        public CountryListView()
        {
            InitializeComponent();

            vm = new CountryListViewModel();
            BindingContext = vm;
        }

        protected async override void OnAppearing()
        {
            base.OnAppearing();

            if (vm.Countries.Count == 0)
            {
                await Task.Run(() => vm.LoadDataCommand.Execute(null));
            }
            else
            {
                vm.SelectedCountry = null;
            }
        }
    }
}