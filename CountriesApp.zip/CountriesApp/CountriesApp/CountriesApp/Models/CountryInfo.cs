﻿using System.Collections.Generic;

namespace CountriesApp.Models
{
    public class CountryInfo
    {
        public List<Country> Geonames { get; set; }
    }
}