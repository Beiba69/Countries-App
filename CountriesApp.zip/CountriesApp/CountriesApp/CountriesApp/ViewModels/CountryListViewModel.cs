﻿using System.Linq;
using System.Windows.Input;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections.ObjectModel;

using Xamarin.Forms;

using CountriesApp.Models;
using CountriesApp.Services;
using CountriesApp.Views;

namespace CountriesApp.ViewModels
{
    public class CountryListViewModel : BaseViewModel
    {
        public ObservableCollection<Country> Countries { get; }

        private Country selectedCountry;

        public Country SelectedCountry
        {
            get { return selectedCountry; }
            set { SetProperty(ref selectedCountry, value); }
        }

        public ICommand LoadDataCommand { private set; get; }
        public ICommand LoadMoreCommand { private set; get; }
        public ICommand GoToDetailCommand { private set; get; }
        public ICommand RefreshDataCommand { private set; get; }

        int page = 0;
        int pageSize = 10;
        private List<Country> CountryList;
        private bool isRefreshing;

        private void LoadData()
        {
            IsBusy = true;
        }

        private void LoadMore()
        {
            if (!isRefreshing)
            {
                page++;
                LoadFlags();
            }
        }

        private async Task RefreshData()
        {
            isRefreshing = true;
            page = 0;
            await CallApiService();
            LoadFlags();
            isRefreshing = false;
        }

        private async Task CallApiService()
        {
            Countries.Clear();
            CountryList = await GeonamesService.GetCountries();
            //CountryList = CountryList.Take(30).ToList();
            IsBusy = false;
        }

        private void LoadFlags()
        {
            int totalPages = CountryList.Count / pageSize + 1;

            if (page < totalPages)
            {
                IEnumerable<Country> countrySet =
                    CountryList.Skip(page * pageSize).Take(pageSize);

                foreach (Country country in countrySet)
                {
                    string code = country.CountryCode.ToLower();
                    country.FlagUrl = $"https://raw.githubusercontent.com/hjnilsson/country-flags/master/png250px/{code}.png";
                    Countries.Add(country);
                }
            }
        }

        private async Task GoToDetail()
        {
            if (SelectedCountry != null)
            {
                CountryDetailViewModel viewModel = new CountryDetailViewModel();
                viewModel.SelectedCountry = SelectedCountry;

                CountryDetailView view = new CountryDetailView();
                view.BindingContext = viewModel;

                await App.Current.MainPage.Navigation.PushAsync(view);
            }
        }

        public CountryListViewModel()
        {
            CountryList = new List<Country>();
            Countries = new ObservableCollection<Country>();
            page = 0;

            LoadDataCommand = new Command(LoadData);
            LoadMoreCommand = new Command(LoadMore);
            GoToDetailCommand = new Command(async () => await GoToDetail());
            RefreshDataCommand = new Command(async () => await RefreshData());
        }
    }
}
