﻿using CountriesApp.Models;

namespace CountriesApp.ViewModels
{
    public class CountryDetailViewModel : BaseViewModel
    {
        private Country selectedCountry;

        public Country SelectedCountry
        {
            get { return selectedCountry; }
            set { SetProperty(ref selectedCountry, value); }
        }
    }
}
